(function() {
    "use strict";

    var SECT_CLASS_RX = /^sect(\d)$/;

    var navContainer = document.querySelector(".nav-container");

    navContainer.addEventListener("click", trapEvent);

    const panels = navContainer.querySelector(".panels");
    var menuPanel = navContainer.querySelector("[data-panel=menu]");
    if (!menuPanel) return;

    var currentPageItem = menuPanel.querySelector(".is-current-page");
    var originalPageItem = currentPageItem;
    if (currentPageItem) {
        activateCurrentPath(currentPageItem);
        scrollItemToMidpoint(currentPageItem.querySelector(".nav-link"));
    } else {
        panels.scrollTop = 0;
    }

    find(menuPanel, ".nav-text-toggle-button, .nav-text-toggle, .nav-text-toggle-button + .nav-text").forEach((el) =>
        el.addEventListener("click", toggleActive.bind(el.closest("li")))
    );

    // NOTE prevent text from being selected by double click
    menuPanel.addEventListener("mousedown", function(e) {
        if (e.detail > 1) e.preventDefault();
    });

    var explorePanels = document.querySelectorAll('.nav-panel-explore');
    explorePanels.forEach(function(explorePanel, index) {
        console.log(`Attaching event listener to explorePanel ${index}`); // Step 1

        const contextContainer = explorePanel.querySelector(".context-container");
        if (contextContainer) {
            contextContainer.addEventListener("click", function () {
                console.log(`Click event triggered on explorePanel ${index}`); // Step 2
                console.log(`Before toggle: ${explorePanel.classList}`); // Step 3
                explorePanel.classList.toggle("is-active");
                console.log(`After toggle: ${explorePanel.classList}`); // Step 3
            });
        }

        function closeExplorePanel(ev) {
            if (explorePanel.contains(ev.target)) {
                return;
            }
            explorePanel.classList.toggle("is-active", false);
        }

        window.addEventListener("click", closeExplorePanel);
    });

    function onHashChange() {
        var navLink;
        var hash = window.location.hash;
        if (hash) {
            if (hash.indexOf("%")) hash = decodeURIComponent(hash);
            navLink = menuPanel.querySelector('.nav-link[href="' + hash + '"]');
            if (!navLink) {
                var targetNode = document.getElementById(hash.slice(1));
                if (targetNode) {
                    var current = targetNode;
                    var ceiling = document.querySelector("article.doc");
                    while ((current = current.parentNode) && current !== ceiling) {
                        var id = current.id;
                        // NOTE: look for section heading
                        if (!id && (id = SECT_CLASS_RX.test(current.className)))
                            id = (current.firstElementChild || {}).id;
                        if (id && (navLink = menuPanel.querySelector('.nav-link[href="#' + id + '"]'))) break;
                    }
                }
            }
        }
        var navItem;
        if (navLink) {
            navItem = navLink.parentNode;
        } else if (originalPageItem) {
            navLink = (navItem = originalPageItem).querySelector(".nav-link");
        } else {
            return;
        }
        if (navItem === currentPageItem) return;
        find(menuPanel, ".nav-item.is-active").forEach(function(el) {
            el.classList.remove("is-active", "is-current-path", "is-current-page");
        });
        navItem.classList.add("is-current-page");
        currentPageItem = navItem;
        activateCurrentPath(navItem);
        scrollItemToMidpoint(navLink);
    }

    if (menuPanel.querySelector('.nav-link[href^="#"]')) {
        if (window.location.hash) onHashChange();
        window.addEventListener("hashchange", onHashChange);
    }

    function activateCurrentPath(navItem) {
        var ancestorClasses;
        var ancestor = navItem.parentNode;
        while (!(ancestorClasses = ancestor.classList).contains("nav-menu")) {
            if (ancestor.tagName === "LI" && ancestorClasses.contains("nav-item")) {
                ancestorClasses.add("is-active", "is-current-path");
            }
            ancestor = ancestor.parentNode;
        }
        navItem.classList.add("is-active");
    }

    function toggleActive() {
        if (this.classList.toggle("is-active")) {
            var padding = parseFloat(window.getComputedStyle(this).marginTop);
            var rect = this.getBoundingClientRect();
            var menuPanelRect = menuPanel.getBoundingClientRect();
            var overflowY = (rect.bottom - menuPanelRect.top - menuPanelRect.height + padding).toFixed();
            if (overflowY > 0)
                menuPanel.scrollTop += Math.min((rect.top - menuPanelRect.top - padding).toFixed(), overflowY);
        }
    }

    function trapEvent(e) {
        e.stopPropagation();
    }

    function scrollItemToMidpoint(el) {
        const panelsRect = panels.getBoundingClientRect();
        const elRect = el.getBoundingClientRect();
        const panelsCenter = panelsRect.top + panelsRect.height / 2;
        const elCenter = elRect.top + elRect.height / 2;
        panels.scrollTop += elCenter - panelsCenter;
    }

    function find(from, selector) {
        return [].slice.call(from.querySelectorAll(selector));
    }
})();

(function() {
    "use strict";

    var sidebar = document.querySelector("aside.toc.sidebar");
    if (!sidebar) return;
    if (document.querySelector("body.-toc")) return sidebar.parentNode.removeChild(sidebar);
    var levels = parseInt(sidebar.dataset.levels || 2, 10);
    if (levels < 0) return;

    var articleSelector = "article.doc";
    var article = document.querySelector(articleSelector);
    var headingsSelector = [];
    for (var level = 0; level <= levels; level++) {
        var headingSelector = [articleSelector];
        if (level) {
            for (var l = 1; l <= level; l++) headingSelector.push((l === 2 ? ".sectionbody>" : "") + ".sect" + l);
            headingSelector.push("h" + (level + 1) + "[id]");
        } else {
            headingSelector.push("h1[id].sect0");
        }
        headingsSelector.push(headingSelector.join(">"));
    }
    var headings = find(headingsSelector.join(","), article.parentNode);
    if (!headings.length) return sidebar.parentNode.removeChild(sidebar);

    var lastActiveFragment;
    var links = {};
    var list = headings.reduce(function(accum, heading) {
        var link = document.createElement("a");
        link.textContent = heading.textContent;
        links[(link.href = "#" + heading.id)] = link;
        var listItem = document.createElement("li");
        listItem.dataset.level = parseInt(heading.nodeName.slice(1), 10) - 1;
        listItem.appendChild(link);
        accum.appendChild(listItem);
        return accum;
    }, document.createElement("ul"));

    var menu = sidebar.querySelector(".toc-menu");
    if (!menu) (menu = document.createElement("div")).className = "toc-menu";

    var title = document.createElement("h3");
    title.textContent = sidebar.dataset.title || "On this page";
    menu.appendChild(title);
    menu.appendChild(list);

    var startOfContent = !document.getElementById("toc") && article.querySelector("h1.page ~ :not(.is-before-toc)");
    if (startOfContent) {
        var embeddedToc = document.createElement("aside");
        embeddedToc.className = "toc embedded";
        if (sidebar.querySelector(".no-toc")) { embeddedToc.className += " no-toc"; }
        // Check if an element with class 'nav-panel-explore' exists
        var explorePanel = document.querySelector('.nav-panel-explore');
        if (explorePanel) { embeddedToc.appendChild(explorePanel.cloneNode(true)); }
        embeddedToc.appendChild(menu.cloneNode(true));
        startOfContent.parentNode.insertBefore(embeddedToc, startOfContent);
    }

    window.addEventListener("load", function() {
        onScroll();
        window.addEventListener("scroll", onScroll);
    });

    function onScroll() {
        var scrolledBy = window.pageYOffset;
        var buffer = getNumericStyleVal(document.documentElement, "fontSize") * 1.15;
        var ceil = article.offsetTop;
        if (scrolledBy && window.innerHeight + scrolledBy + 2 >= document.documentElement.scrollHeight) {
            lastActiveFragment = Array.isArray(lastActiveFragment)
                ? lastActiveFragment
                : Array(lastActiveFragment || 0);
            var activeFragments = [];
            var lastIdx = headings.length - 1;
            headings.forEach(function(heading, idx) {
                var fragment = "#" + heading.id;
                if (
                    idx === lastIdx ||
                    heading.getBoundingClientRect().top + getNumericStyleVal(heading, "paddingTop") > ceil
                ) {
                    activeFragments.push(fragment);
                    if (lastActiveFragment.indexOf(fragment) < 0) links[fragment].classList.add("is-active");
                } else if (~lastActiveFragment.indexOf(fragment)) {
                    links[lastActiveFragment.shift()].classList.remove("is-active");
                }
            });
            list.scrollTop = list.scrollHeight - list.offsetHeight;
            lastActiveFragment = activeFragments.length > 1 ? activeFragments : activeFragments[0];
            return;
        }
        if (Array.isArray(lastActiveFragment)) {
            lastActiveFragment.forEach(function(fragment) {
                links[fragment].classList.remove("is-active");
            });
            lastActiveFragment = undefined;
        }
        var activeFragment;
        headings.some(function(heading) {
            if (heading.getBoundingClientRect().top + getNumericStyleVal(heading, "paddingTop") - buffer > ceil)
                return true;
            activeFragment = "#" + heading.id;
        });
        if (activeFragment) {
            if (activeFragment === lastActiveFragment) return;
            if (lastActiveFragment) links[lastActiveFragment].classList.remove("is-active");
            var activeLink = links[activeFragment];
            activeLink.classList.add("is-active");
            if (list.scrollHeight > list.offsetHeight) {
                list.scrollTop = Math.max(0, activeLink.offsetTop + activeLink.offsetHeight - list.offsetHeight);
            }
            lastActiveFragment = activeFragment;
        } else if (lastActiveFragment) {
            links[lastActiveFragment].classList.remove("is-active");
            lastActiveFragment = undefined;
        }
    }

    function find(selector, from) {
        return [].slice.call((from || document).querySelectorAll(selector));
    }

    function getNumericStyleVal(el, prop) {
        return parseFloat(window.getComputedStyle(el)[prop]);
    }
})();

(function() {
  "use strict";

  document.querySelectorAll(".clickable").forEach(el => {
    const innerLink = el.querySelector("a");
    if (innerLink) {
      el.addEventListener("click", () => innerLink.click());
    }
  });
})();

(function() {
    "use strict";

    const navButton = document.querySelector(".nav-toggle-button");
    const nav = document.querySelector(".nav");
    if (!navButton || !nav) return;

    navButton.addEventListener("click", (ev) => {
        document.documentElement.classList.toggle("is-clipped--navbar");
        nav.classList.toggle("nav-opened");
        navButton.classList.toggle("nav-opened");
    });
})();

(function() {
  "use strict";

  var CMD_RX = /^\$ (\S[^\\\n]*(\\\n(?!\$ )[^\\\n]*)*)(?=\n|$)/gm;
  var LINE_CONTINUATION_RX = /( ) *\\\n *|\\\n( ?) */g;
  var TRAILING_SPACE_RX = / +$/gm;

  var supportsCopy = window.navigator.clipboard;

  [].slice
    .call(
      document.querySelectorAll(".doc pre.highlight, .doc .literalblock pre")
    )
    .forEach(function(pre) {
      var code, language, lang, copy, toast, toolbox;
      if (pre.classList.contains("highlight")) {
        code = pre.querySelector("code");
        if ((language = code.dataset.lang) && language !== "console") {
          (lang = document.createElement("span")).className = "source-lang";
          lang.appendChild(document.createTextNode(language));
        }
      } else if (pre.innerText.startsWith("$ ")) {
        var block = pre.parentNode.parentNode;
        block.classList.remove("literalblock");
        block.classList.add("listingblock");
        pre.classList.add("highlightjs", "highlight");
        (code = document.createElement("code")).className =
          "language-console hljs";
        code.dataset.lang = "console";
        code.appendChild(pre.firstChild);
        pre.appendChild(code);
      } else {
        return;
      }
      (toolbox = document.createElement("div")).className = "source-toolbox";
      if (lang) toolbox.appendChild(lang);
      if (supportsCopy) {
        (copy = document.createElement("button")).className = "copy-button";
        copy.setAttribute("title", "Copy to clipboard");
        var div = document.createElement("div");
        div.className = "copy-icon";
        copy.appendChild(div);
        (toast = document.createElement("span")).className = "copy-toast";
        toast.appendChild(document.createTextNode("Copied!"));
        copy.appendChild(toast);
        toolbox.appendChild(copy);
      }
      pre.parentNode.appendChild(toolbox);
      if (copy)
        copy.addEventListener("click", writeToClipboard.bind(copy, code));
    });

  function extractCommands(text) {
    var cmds = [];
    var m;
    while ((m = CMD_RX.exec(text)))
      cmds.push(m[1].replace(LINE_CONTINUATION_RX, "$1$2"));
    return cmds.join(" && ");
  }

  function writeToClipboard(code) {
    var text = code.innerText.replace(TRAILING_SPACE_RX, "");
    if (code.dataset.lang === "bash" && text.startsWith("$ "))
      text = extractCommands(text);
    window.navigator.clipboard.writeText(text).then(
      function() {
        this.classList.add("clicked");
        this.offsetHeight; // eslint-disable-line no-unused-expressions
        this.classList.remove("clicked");
      }.bind(this),
      function() {}
    );
  }
})();

(function() {
  "use strict";
  var ISSUE_MAX_QUOTE_LENGTH = 1000;
  var ISSUE_REQUEST_URL = "https://github.com/vaticle/typedb-docs/issues/new";
  var ISSUE_TEMPLATE = "CHANGE_REQUEST.yml";
  var ISSUE_DEFAULT_TITLE = "New change request";
  var ISSUE_DEFAULT_DESCRIPTION = `

[describe your issue here]`;
  var selected_quote = "";

  var issueContainer = document.querySelector(".issue-link");

  if (issueContainer) {
    issueContainer.addEventListener("mousedown", getQuotedText);
    issueContainer.addEventListener("click", openIssue);
  }

  var brokenLinkReport = document.querySelector(".broken-link-report");

  if (brokenLinkReport) {
    brokenLinkReport.addEventListener("click", openBrokenLinkIssue);
  }

  function openIssue() {
    var article_url = window.location.href;
    var issue_preamble = selected_quote + ISSUE_DEFAULT_DESCRIPTION;

    var url = ISSUE_REQUEST_URL +
      "?template=" + ISSUE_TEMPLATE + 
      "&title=" + ISSUE_DEFAULT_TITLE +
      "&article=" + encodeURIComponent(article_url) + 
      "&issue-description=" + encodeURIComponent(issue_preamble);
    window.open(url, '_blank').focus();
  }

  function openBrokenLinkIssue() {
    var article_url = window.location.href;
    var issue_preamble = "Broken Link: ";

    var url = ISSUE_REQUEST_URL +
      "?template=" + ISSUE_TEMPLATE + 
      "&title=" + encodeURIComponent("Found Broken Link") +
      "&issue-description=" + encodeURIComponent(issue_preamble) + encodeURIComponent(article_url);
    window.open(url, '_blank').focus();
  }

  function getQuotedText() {
    var text = "";
    if (window.getSelection) {
        text = window.getSelection().toString();
    } else if (document.selection && document.selection.type != "Control") {
        text = document.selection.createRange().text;
    }
    if (text == "") text = "(no text to quote was selected)";
    console.log("selected text:" + text);
    selected_quote = text.substring(0,ISSUE_MAX_QUOTE_LENGTH).replace(/^/gm, '> ');
  }
})();
(function() {
  "use strict";

  var tables = document.querySelectorAll('table.tableblock.frame-all.grid-all.stretch');
  tables.forEach(function(table) {
    var wrapper = document.createElement('div');
    wrapper.className = 'table_wrapper';
    table.parentNode.insertBefore(wrapper, table);
    wrapper.appendChild(table);
  });

})();
(function () {
  'use strict'

  const SUPPORTED = ['typeql', 'python', 'rust']

  // --- TypeDB Console Script syntax ---
  const DEFAULT_DB = 'db_test'

  const CONSOLE = {
    txn_open: {
      schema: 'transaction schema',
      write: 'transaction write',
      read: 'transaction read',
    },
    send_q: '', // sending a query just adds new line
    commit: 'commit',
    close: 'close',
    comments: {
      failure: {
        attribute: 'fail_at', // Test attribute (see typeql_runner.py)
        comment: 'Will fail.',
      },
      rollback: {
        attribute: 'rollback', // Test attribute (see typeql_runner.py)
        comment: 'Don\'t commit.',
      },
      count: {
        attribute: 'count', // Test attribute (see typeql_runner.py)
        comment: 'Answer count: ',
      },
    },
  }

  // --- Keep this synced with typedb-docs: code_test/parser/parser.py ---
  const TXN_TYPE_REGEX = /^.+?test\[(schema|write|read)\b/
  const TXN_DB_REGEX = /^.+?test\[(?:.+?db=(.+?))?\b/
  const TXN_COUNT_REGEX = /^.+?test\[(?:.+?count=(.+?))?\b/
  const MARKERS = {
    typeql: {
      test_start: '#!test',
      hidden_segment_start: '#{{',
      hidden_segment_end: '#}}',
      segment_separator: '#---',
      ordered_macro: '#!ordered',
      skip_lines: '#!!',
    },
    python: {
      test_start: '#!test',
      hidden_segment_start: '#{{',
      hidden_segment_end: '#}}',
      segment_separator: '#---',
      ordered_macro: '#!ordered',
      skip_lines: '#!!',
    },
    rust: {
      test_start: '//!test',
      hidden_segment_start: '//{{',
      hidden_segment_end: '//}}',
      segment_separator: '//---',
      ordered_macro: '//!ordered',
      skip_lines: '//!!',
    },
  }

  // 'Enum' for parser logic
  const QueryParserState = {
    NONE: null, // we are not (yet) in a query
    VISIBLE: 'visible', // we are in a visible query
    HIDDEN: 'hidden', // we are in a hidden query
  }

  // Prism is our default syntax highlighter ... we have to wait for it
  // to finish highlighting before we can start hiding code snippets.
  function waitForPrism (code, callback) {
    if (code.querySelector('span.token')) {
      callback()
    } else {
      // console.log('Prism has not yet finished highlighting this block; wait 20ms...')
      setTimeout(function () {
        waitForPrism(code, callback)
      }, 20)
    }
  }

  function hideLine (line) {
    return '<span class="hidden-line">' + line + '</span>'
  }

  function commentStr (str) {
    return '<span class="token comment">' + str + '</span>'
  }

  function consoleStr (str) {
    return '<span class="token console">' + str + '</span>'
  }

  function startTxn (ongoingTransaction) {
    const dbString = ' ' + ongoingTransaction.db
    return hideLine(consoleStr(CONSOLE.txn_open[ongoingTransaction.type] + dbString))
  }

  function terminateTxn (ongoingTransaction) {
    const countComment = ongoingTransaction.count ? CONSOLE.comments.count.comment + ongoingTransaction.count + '.' : ''
    const failureComment = ongoingTransaction.failure ? CONSOLE.comments.failure.comment : ''
    const rollbackComment = ongoingTransaction.rollback ? CONSOLE.comments.rollback.comment : ''
    const commentStart = (ongoingTransaction.failure || ongoingTransaction.rollback || ongoingTransaction.count) ? ' # ' : ''
    return hideLine(consoleStr(CONSOLE[ongoingTransaction.ends_with]) + commentStr(commentStart + countComment + failureComment + rollbackComment))
  }

  function mayTerminateQuery (currentState, resetState) {
    if (currentState === resetState || currentState === QueryParserState.NONE) {
      return null
    } else {
      return hideLine(consoleStr(CONSOLE.send_q))
    }
  }

  [].slice
    .call(document.querySelectorAll('.doc pre.highlight, .doc .literalblock pre'))
    .forEach(function (pre, index) {
      const code = pre.querySelector('code')
      if (!code) {
        console.warn('No <code> element found in code block', index)
        return
      }

      const lang = code.dataset.lang
      if (!SUPPORTED.includes(lang)) {
        // console.log('Skipping code block', index, 'with language', code.dataset.lang)
        return
      }

      waitForPrism(code, function () {
        // console.log('Prism finished highlighting block', index)
        const html = code.innerHTML
        const lines = html.split('\n')
        const formattedLines = []

        // TypeQL-specific parser state
        let queryState = QueryParserState.NONE
        const ongoingTransaction = {
          type: null,
          db: null,
          count: null,
          failure: null,
          rollback: null,
          ends_with: null,
        }

        for (let i = 0; i <= lines.length; i++) {
          if (i === lines.length) {
            if (lang === 'typeql' && ongoingTransaction.type != null) {
              formattedLines.push(hideLine(''))
              formattedLines.push(terminateTxn(ongoingTransaction))
            }
            break
          }
          // console.log('Processing line number ' + i)
          const line = lines[i]

          if (line.indexOf(MARKERS[lang].test_start) !== -1) {
            // console.log('Found test start at line', i, 'in block', index)
            if (lang === 'typeql') {
              if (ongoingTransaction.type != null) {
                const terminateQueryCommand = mayTerminateQuery(queryState, QueryParserState.NONE)
                if (terminateQueryCommand != null) {
                  formattedLines.push(terminateQueryCommand)
                }
                queryState = QueryParserState.NONE
                formattedLines.push(terminateTxn(ongoingTransaction))
                formattedLines.push(hideLine(''))
              }
              const txnTypeMatch = line.match(TXN_TYPE_REGEX)
              const txnDBMatch = line.match(TXN_DB_REGEX)
              const txnCountMatch = line.match(TXN_COUNT_REGEX)
              if (!(txnTypeMatch)) {
                console.warn('Found typeql test without valid transaction type')
                continue
              }
              // TODO: parse out answer count test attribute
              ongoingTransaction.type = txnTypeMatch[1]
              ongoingTransaction.db = txnDBMatch[1] || DEFAULT_DB
              ongoingTransaction.count = txnCountMatch[1] || null
              ongoingTransaction.failure = (line.indexOf(CONSOLE.comments.failure.attribute) !== -1)
              ongoingTransaction.rollback = (line.indexOf(CONSOLE.comments.rollback.attribute) !== -1)
              ongoingTransaction.ends_with = (ongoingTransaction.failure || ongoingTransaction.rollback || ongoingTransaction.type === 'read') ? 'close' : 'commit'
              formattedLines.push(startTxn(ongoingTransaction))
            }
            continue
          }

          if (line.indexOf(MARKERS[lang].hidden_segment_start) !== -1) {
            // console.log('Found hidden segment start at line', i, 'in block', index)
            if (lang === 'typeql') {
              const terminateQueryCommand = mayTerminateQuery(queryState, QueryParserState.NONE)
              if (terminateQueryCommand != null) {
                formattedLines.push(terminateQueryCommand)
              }
              queryState = QueryParserState.HIDDEN
            }
            i++
            while (i < lines.length && lines[i].indexOf(commentStr(MARKERS[lang].hidden_segment_end)) === -1) {
              formattedLines.push(hideLine(lines[i]))
              i++
            }
            // console.log('Found hidden segment end at line', i - 1, 'in block', index)
            continue
          }

          if (line.indexOf(MARKERS[lang].segment_separator) !== -1) {
            // console.log('Found segment separator at line', i, 'in block', index)
            switch (lang) {
              case 'typeql':
                formattedLines.push(hideLine(consoleStr(CONSOLE.send_q)))
                break
              case 'rust':
                formattedLines.push(hideLine(''))
                break
              case 'python':
                formattedLines.push(hideLine(''))
                break
            }
            continue
          }

          if (line.indexOf(MARKERS[lang].ordered_macro) !== -1) {
            // console.log('Found ordered macro at line', i, 'in block', index)
            switch (lang) {
              case 'typeql':
                formattedLines.push(hideLine(commentStr('# Note: Run earlier queries before running this query')))
                break
              case 'rust':
                formattedLines.push(hideLine(commentStr('// Note: Run earlier queries before running this query')))
                break
              case 'python':
                formattedLines.push(hideLine(commentStr('# Note: Run earlier examples before running this example')))
                break
            }
            continue
          }

          var skipLinesMatch = line.match(`${MARKERS[lang].skip_lines}(\\d+)`)
          if (skipLinesMatch) {
            // console.log('Found hidden-lines marker at line', i, 'in block', index, 'n =', skipLinesMatch[1])
            var n = parseInt(skipLinesMatch[1], 10)
            for (var j = 0; j < n; j++) {
              i++
              if (i < lines.length) {
                formattedLines.push(hideLine(lines[i]))
              }
            }
            queryState = true
            continue
          }

          // Otherwise, this line must belong to an actual (visible) query
          if (lang === 'typeql') {
            const terminateQueryCommand = mayTerminateQuery(queryState, QueryParserState.VISIBLE)
            if (terminateQueryCommand != null) {
              formattedLines.push(terminateQueryCommand)
            }
            queryState = QueryParserState.VISIBLE
          }
          // console.log('Found #' + i + ' line is visible: ' + line)
          formattedLines.push(line)
        }

        var fullContent = formattedLines.join('\n')
        var visibleContent = formattedLines
          .filter(function (line) {
            return line.indexOf('class="hidden-line"') === -1
          })
          .join('\n')

        code.dataset.fullContent = fullContent
        code.dataset.visibleContent = visibleContent
        code.innerHTML = visibleContent
        // console.log('Finished transforming code block', index)

        var container = pre.parentNode
        var toolbox = container.querySelector('.source-toolbox')
        if (!toolbox) {
          toolbox = document.createElement('div')
          toolbox.className = 'source-toolbox'
          container.appendChild(toolbox)
          // console.log('Created new toolbox for block', index)
        } else {
          // console.log('Found existing toolbox for block', index)
        }

        var toggle = document.createElement('button')
        toggle.className = 'toggle-hidden-button'
        toggle.setAttribute('title', 'Toggle hidden lines')

        var icon = document.createElement('div')
        icon.className = 'toggle-hidden-icon'
        toggle.appendChild(icon)

        if (visibleContent !== fullContent) {
          toolbox.appendChild(toggle)
          // console.log('Appended toggle button to toolbox for block', index)
        } else {
          // console.log('Did not create toggle: no content to toggle', index)
        }

        toggle.addEventListener('click', function () {
          if (pre.classList.contains('show-hidden-lines')) {
            code.innerHTML = code.dataset.visibleContent
            pre.classList.remove('show-hidden-lines')
            toggle.classList.remove('active')
            // console.log('Hidden lines removed for block', index)
          } else {
            code.innerHTML = code.dataset.fullContent
            pre.classList.add('show-hidden-lines')
            toggle.classList.add('active')
            // console.log('Hidden lines restored for block', index)
          }
        })
      })
    })
})()
